<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 10/08/2022
 */

/*
 EasyToYou.eu Decoder: The encoded file don't contain any php code to extract,
 The encoded file is used as empty, only php tag "<?php // nothing here. ?>". 
*/

?>